# 66:20 Organización de Computadoras
Trabajo práctico #0: Infraestructura básica
1er cuatrimestre de 2017

Compilar con:
gcc -Wall main.c

Ejecutar con:
./a.out -i entrada -o salida

Compilar el informe en latex con:
pdflatex tp0.tex (Estando dentro de la carpeta latex)
Se necesita instalar text-live (pesa alrededor de 1 giga)
sudo apt-get install texlive-full
